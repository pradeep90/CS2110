/********************************************************************** 
 * Program name : Logical Equivalence
 * Program : To get two logical expressions and 
 *           check if truth tables are identical
 * Date : 13 August 2010
 * Successful!!!
 * Works with command line arguments!!

************************************************************************/

#include <stdio.h>
#include <string.h>
#include "postfix.h"

char ipstr[100] = "";
int fnvalues1[1000], fnvalues2[1000], numvar;

int get_expression(char ipstr[])
{
     /*
      * Arguments :
      * char ipstr[] - The infix expression from user goes here
      *
      * Return : Nothing in particular
      */


     printf("Operators : \n& AND\n~ Not\n| OR\n> IMPLIES\n= IMPLIES AND IS IMPLIED BY\n");
     printf("Use any alphabets to denote your variables\n");
     printf("Please enter your logical expression : \n");
     gets(ipstr);
}

int equivalent(int arr1[], int arr2[], int numvar)
{
     /*
      * Arguments :
      * arr1[] - Array of truth values for function 1
      * arr2[] - Array of truth values for function 2
      * numvar - number of total variables
      * Return : Whether two arrays have identical values
      */


     int i, flag = 0;
     for(i=0; i<(1<<numvar); i++){
	  if(arr1[i] != arr2[i]){
	       flag = 1;
	       return 0;
	  }
     }
     return 1;
}

	       
	  

int main(int argc, char *argv[]){
     int i, j, output;

     if(argc == 1){
	  printf("Logical Expression 1 :\n");
	  get_expression(ipstr);
	  truth_table(ipstr, fnvalues1, &numvar);

	  printf("\nLogical Expression 2 :\n");
	  get_expression(ipstr);
	  truth_table(ipstr, fnvalues2, &numvar);

	  if(equivalent(fnvalues1, fnvalues2, numvar))
	       printf("\nThe given functions are equivalent!\n");
	  else
	       printf("\nThe given functions are NOT equivalent!\n");
     }
     else if(argc != 3){
	  printf("Please enter exactly two logical expressions!");
	  return 0;
     }
     else{
	  printf("Logical Expression 1 :\n");
	  strcpy(ipstr, argv[1]);
	  truth_table(ipstr, fnvalues1, &numvar);

	  printf("\nLogical Expression 2 :\n");
	  strcpy(ipstr, argv[2]);	  
	  truth_table(ipstr, fnvalues2, &numvar);

	  if(equivalent(fnvalues1, fnvalues2, numvar))
	       printf("\nThe given functions are equivalent!\n");
	  else
	       printf("\nThe given functions are NOT equivalent!\n");

     }
     
     return 0;
}


